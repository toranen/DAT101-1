"use strict";

import { initPrintOut, printOut, NEWLine } from "../common/script/utils.mjs";
initPrintOut(document.getElementById("txtOut"));

  /* Put your code below here!*/
  let txtPrintValue;

  txtPrintValue = "----  Task 1 -----";
  printOut(txtPrintValue);

  function printOutToday() {
    const options = {weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'};
    const dateToday = new Date();
    txtPrintValue = dateToday.toLocaleDateString("no-BM", options);
    printOut(txtPrintValue);
    return dateToday;
  }

  printOutToday();

  txtPrintValue = "----  Task 2 -----";
  printOut(NEWLine + txtPrintValue);

  function printOutDaysToSony(aDate) {
    const millisecondInDay = 8.64e+7;
    const releaseDate = new Date("02/12/2020");
    const days = Math.floor((releaseDate - aDate) / millisecondInDay);
    txtPrintValue = "It is " + days + " days to release of Sony Playstation 5";
    printOut(txtPrintValue);
  }

  printOutDaysToSony(printOutToday());


  txtPrintValue = "----  Task 3 -----";
  printOut(NEWLine + txtPrintValue);

  function calcCircle(aRadius) {
    const Diameter = aRadius * 2;
    txtPrintValue = "Diameter is " + Diameter.toString() + NEWLine;
    txtPrintValue += "Circumference is " + (Diameter * Math.PI).toFixed(2) + NEWLine;
    txtPrintValue += "Areal is " + (Math.pow(aRadius, 2) * Math.PI).toFixed(2);
    printOut(txtPrintValue);
  }

  calcCircle(5);

  txtPrintValue = "----  Task 4 -----";
  printOut(NEWLine + txtPrintValue);

  function calcRect(aRect) {
    txtPrintValue = "Rectangle width: " + aRect.width.toString() + ", height: " + aRect.height.toString() + NEWLine;
    txtPrintValue += "Circumference is " + ((aRect.width * 2) + (aRect.height * 2)).toFixed(2) + NEWLine;
    txtPrintValue += "Areal is " + (aRect.width * aRect.height).toFixed(2);
    printOut(txtPrintValue);
  }

  calcRect({width: 4, height: 3});

  txtPrintValue = "----  Task 5 -----";
  printOut(NEWLine + txtPrintValue);
  const ETemperatureID = {Celsius: 1, Fahrenheit: 2, Kelvin: 3};

  function convertTemperature(aTemperature, aTemperatureID) {
    txtPrintValue = aTemperature.toString() + " degrease in ";
    const temperature = {Celsius: 0, Fahrenheit: 0, Kelvin: 0};
    switch (aTemperatureID) {
      case ETemperatureID.Celsius:
        txtPrintValue = "Convert " + aTemperature + " Celsius" + NEWLine;
        temperature.Celsius = aTemperature;
        temperature.Fahrenheit = (aTemperature * 9 / 5) + 32;
        temperature.Kelvin = aTemperature + 273.15;
        break;
      case ETemperatureID.Fahrenheit:
        txtPrintValue = "Convert " + aTemperature + " Fahrenheit" + NEWLine;
        temperature.Celsius = (aTemperature - 32) * (5 / 9);
        temperature.Fahrenheit = aTemperature;
        temperature.Kelvin = (aTemperature + 459.67) * (5 / 9);
        break;
      case ETemperatureID.Kelvin:
        txtPrintValue = "Convert " + aTemperature + " Kelvin" + NEWLine;
        temperature.Celsius = aTemperature - 273.15;
        temperature.Fahrenheit = (aTemperature * 9 / 5) - 459.67;
        temperature.Kelvin = aTemperature;
        break;
    }
    txtPrintValue += "Celsius = " + Math.round(temperature.Celsius).toString() + NEWLine;
    txtPrintValue += "Fahrenheit = " + Math.round(temperature.Fahrenheit).toString() + NEWLine;
    txtPrintValue += "Kelvin = " + Math.round(temperature.Kelvin).toString() + NEWLine;
    printOut(txtPrintValue);
  }

  convertTemperature(47, ETemperatureID.Celsius);
  convertTemperature(100, ETemperatureID.Fahrenheit);
  convertTemperature(300, ETemperatureID.Kelvin);

  txtPrintValue = "----  Task 6 -----";
  printOut(NEWLine + txtPrintValue);

  function grossToNetPrice(aGross, aVATGroup) {
    let VAT;
    aVATGroup = aVATGroup.toLowerCase();
    switch (aVATGroup) {
      case "normal":
        VAT = 25;
        break;
      case "food":
        VAT = 15;
        break;
      case "hotel":
      case "transport":
      case "cinema":
        VAT = 10;
        break;
      default:
        return NaN;
    }
    return ((100 * aGross) / (VAT + 100)).toFixed(2);
  }

  for (let f = 0; f < 4; f++) {
    let grossPrice;
    let VATGroup;
    switch (f) {
      case 0:
        grossPrice = 100;
        VATGroup = "normal";
        break;
      case 1:
        grossPrice = 150;
        VATGroup = "food";
        break;
      case 2:
        grossPrice = 50;
        VATGroup = "transport";
        break;
      case 3:
        grossPrice = 95;
        VATGroup = "Textile";
        break;
    }
    let netPrice = grossToNetPrice(grossPrice, VATGroup);
    if (isNaN(netPrice)) {
      txtPrintValue = VATGroup + " is unknown tax-group!";
    } else {
      txtPrintValue = grossPrice.toString() + " is " + netPrice.toString() + " without tax";
    }
    printOut(txtPrintValue);
  }

  txtPrintValue = "----  Task 7 -----";
  printOut(NEWLine + txtPrintValue);

  function convertMotion(aSpeed, aDistance, aTime) {
    if ((aSpeed === null || aSpeed === undefined)) {
      return aDistance / aTime;
    } else if ((aDistance === null || aDistance === undefined)) {
      return aSpeed * aTime;
    } else if ((aTime === null || aTime === undefined)) {
      return aDistance / aSpeed;
    } else {
      return NaN;
    }
  }

  for (let f = 0; f < 4; f++) {
    let speed;
    let distance;
    let time;
    switch (f) {
      case 0:
        speed = 75;
        distance = 50;
        time = convertMotion(speed, distance, time);
        break;
      case 1:
        time = 2;
        distance = 120;
        speed = convertMotion(speed, distance, time);
        break;
      case 2:
        time = 1.5;
        speed = 70;
        distance = convertMotion(speed, distance, time);
        break;
      case 3:
        distance = 50;
        time = convertMotion(speed, distance, time);
        break;
    }
    txtPrintValue = "Speed = " + speed + " km/h" + NEWLine;
    txtPrintValue += "Distance = " + distance + " km" + NEWLine;
    txtPrintValue += "Time = " + convertMotion(speed, distance).toFixed(2) + " h" + NEWLine;
    printOut(txtPrintValue);
  }


  txtPrintValue = "----  Task 8 -----";
  printOut(NEWLine + txtPrintValue);

  function extendText(aText, aMaxSize, aCharacter, aTailing) {
    while (aText.length < aMaxSize) {
      if (aTailing) {
        aText += aCharacter;
      } else {
        aText = aCharacter + aText;
      }
    }
    return aText;
  }

  const helloText = "This is a text";
  txtPrintValue = "\"" + extendText(helloText, 55, "\xa0", true) + "\"" + NEWLine;
  txtPrintValue += "\"" + extendText(helloText, 55, "\xa0", false) + "\"" + NEWLine;
  printOut(txtPrintValue);

  txtPrintValue = "----  Task 9 -----";
  printOut(NEWLine + txtPrintValue);
  DOMTextOut.style.fontFamily = 'Courier New';
  txtPrintValue = "";
  let count = 1;
  let round = 1;
  const debugRounds = 8;
  let leftSideText = "", rightSideText = "";

  function calcLeftSide() {
    let result = 0;
    for (let f = 0; f < round + 1; f++) {
      if (round < debugRounds) {
        leftSideText += " " + count;
      }
      result += count++;
    }
    return result;
  }

  function calcRightSide() {
    let result = 0;
    for (let f = 0; f < round; f++) {
      if (round < debugRounds) {
        rightSideText += " " + count;
      }
      result += count++;
    }
    return result;
  }

  for (round = 1; round <= 200; round++) {
    const leftSide = calcLeftSide();
    if (round < debugRounds) {
      txtPrintValue = extendText(leftSideText, 28, "\xa0", false);
      txtPrintValue += " = ";
    }
    const rightSide = calcRightSide();
    if (round < debugRounds) {
      txtPrintValue += extendText(rightSideText, 28, "\xa0", true);
      printOut(txtPrintValue);
    }
    leftSideText = rightSideText = "";
    if (leftSide !== rightSide) {
      printOut("leftSide = " + leftSide + " and rightSide = " + rightSide + ", this is not equal on round " + round);
      break;
    }
  }
  printOut("Mathematics is fun!");

  txtPrintValue = "----  Task 10 -----";
  printOut(NEWLine + txtPrintValue);

  // Factorial of 5 is (5 * 4 * 3 * 2 * 1) = 120
  function factorial(nNumber) {
    if (nNumber <= 1) {
      return 1; // We have reach the end of loop
    } else {
      return nNumber * factorial(nNumber - 1);
    }
  }

  const factorialNumber = Math.ceil(Math.random() * 8) + 2;
  const factorialSum = factorial(factorialNumber);
  txtPrintValue = "factorial(" + factorialNumber + ") is " + factorialSum;
  printOut(txtPrintValue + NEWLine);

"use strict";

import { initPrintOut, printOut, NEWLine } from "../common/script/utils.mjs";
initPrintOut(document.getElementById("txtOut"));

const DOMTextOut = document.getElementById("txtOut");
const Space = "&nbsp;";
//const Space = '\u00a0';

String.prototype.setSize = function (aSize, aString = '\u00a0', aLeading = false) {
    let newString = this.valueOf();
    while (newString.length < aSize) {
        if (aLeading) {
            newString = aString + newString;
        } else {
            newString = newString + aString;
        }
    }
    return newString;
};

/* Put your code below here!*/
let txtPrintValue = "------- Oppgave 1 ------------------------------";
printOut(txtPrintValue);
txtPrintValue = "";
let myArray = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20];
for (let i = 0; i < myArray.length; i++) {
    txtPrintValue += (i > 0 ? ", " : "") + myArray[i].toString();
}
printOut(txtPrintValue + NEWLine);

txtPrintValue = "------- Oppgave 2 ------------------------------";
printOut(txtPrintValue);
txtPrintValue = myArray.join(" - ");
printOut(txtPrintValue + NEWLine);


txtPrintValue = "------- Oppgave 3 ------------------------------";
printOut(txtPrintValue);
txtPrintValue = "";
const myString = "Hei på deg, hvordan har du det?";
myArray = myString.split(" ");
for (let i = 0; i < myArray.length; i++) {
    txtPrintValue += "Ord " + (i + 1).toString() + ", index " + i.toString() + " = " + myArray[i] + (i < myArray.length - 1
        ? NEWLine : "");
}
printOut(txtPrintValue + NEWLine);

txtPrintValue = "------- Oppgave 4 ------------------------------";
printOut(txtPrintValue);

function removeElement(aTable, aName) {
    let index = aTable.indexOf(aName);
    if (index > -1) {
        printOut(aTable.join(", "));
        printOut("Fjerner " + aName + " fra tabellen");
        aTable.splice(index, 1);
        printOut(aTable.join(", "));
    } else {
        printOut(aName + " eksister ikke i tabllen");
    }
}

const namesGirls = ["Anne", "Inger", "Kari", "Marit", "Ingrid", "Liv", "Eva", "Berit", "Astrid", "Bjørg", "Hilde",
    "Anna", "Solveig", "Marianne", "Randi", "Ida", "Nina", "Maria", "Elisabeth", "Kristin"];
removeElement(namesGirls, "Inger");
removeElement(namesGirls, "Camilla");
printOut("");

let girlNames = ["Anne", "Inger", "Kari", "Marit",
    "Ingrid", "Liv", "Eva", "Berit", "Astrid", "Bjørg", "Hilde",
    "Anna", "Solveig", "Marianne", "Randi", "Ida", "Nina", "Maria",
    "Elisabeth", "Kristin"];
printOut(girlNames.join(", "));


txtPrintValue = "------- Oppgave 5 ------------------------------";
printOut(txtPrintValue);

const namesBoys = ["Jakob", "Lucas", "Emil", "Oskar", "Oliver", "William", "Filip", "Noah", "Elias", "Isak", "Henrik",
    "Aksel", "Kasper", "Mathias", "Jonas", "Tobias", "Liam", "Håkon", "Theodor", "Magnus"];
const namesAll = [].concat(namesGirls, namesBoys);
printOut(namesAll.join(", ") + NEWLine);

txtPrintValue = "------- Oppgave 6 ------------------------------";
printOut(txtPrintValue);

function TBook(aTitle, aAuthor, aISBN) {
    const title = aTitle;
    const author = aAuthor;
    const ISBN = aISBN;

    this.toString = function () {
        return "Tittel: " + title + ", Forfatter: " + author + ", ISBN: " + ISBN;
    };
}

const books = [];
books.push(
    new TBook("The Shining", "Stephen King", "978-0-385-12167-5"),
    new TBook("Rage", "Stephen King", "978-0-451-07645-8"),
    new TBook("The Stand", "Stephen King", "978-0-385-12168-2")
);
for (let i = 0; i < books.length; i++) {
    printOut(books[i].toString());
}
printOut(NEWLine);


txtPrintValue = "------- Oppgave 7 ------------------------------";
printOut(txtPrintValue);
txtPrintValue = "";

const EWeekDays = {
    WeekDay1: {value: 0x01, name: "Mandag"},
    WeekDay2: {value: 0x02, name: "Tirsdag"},
    WeekDay3: {value: 0x04, name: "Onsdag"},
    WeekDay4: {value: 0x08, name: "Torsdag"},
    WeekDay5: {value: 0x10, name: "Fredag"},
    WeekDay6: {value: 0x20, name: "Lørdag"},
    WeekDay7: {value: 0x40, name: "Søndag"},
    Workdays: {value: 0x01 + 0x02 + 0x04 + 0x08 + 0x10, name: "Arbeidsdager"},
    Weekends: {value: 0x20 + 0x40, name: "Helg"},
};

const weekDaysKeys = Object.keys(EWeekDays);
printOut("EWeekDays har " + weekDaysKeys.length + " elementer!");
for (let i = 0; i < weekDaysKeys.length; i++) {
    const weekDaysKey = weekDaysKeys[i];
    txtPrintValue += "Element " + i.toString() + " = " + weekDaysKey + ", ";
    const WeekDay = EWeekDays[weekDaysKey];
    txtPrintValue += "name: " + (WeekDay.name + ",").setSize(13);
    txtPrintValue += " value: " + WeekDay.value.toString().setSize(8, '\u00a0', true);
    txtPrintValue += (i < weekDaysKeys.length - 1 ? NEWLine : "");
}
printOut(txtPrintValue + NEWLine);

txtPrintValue = "------- Oppgave 8 ------------------------------";
printOut(txtPrintValue);
const randomValues = [];
const numberOfValues = 35;

function ascendingCompare(aValue1, aValue2) {
    return aValue1 - aValue2;
}

function descendingCompare(aValue1, aValue2) {
    return aValue2 - aValue1;
}

do {
    randomValues.push(Math.ceil(Math.random() * 20));
} while (randomValues.length < numberOfValues);

txtPrintValue = "Unsorted list: ".setSize(20) + randomValues.toString();
printOut(txtPrintValue);
randomValues.sort(ascendingCompare);
txtPrintValue = "Ascending list: ".setSize(20) + randomValues.toString();
printOut(txtPrintValue);
randomValues.sort(descendingCompare);
txtPrintValue = "Descending list: ".setSize(20) + randomValues.toString();
printOut(txtPrintValue + NEWLine);

txtPrintValue = "------- Oppgave 9 ------------------------------";
printOut(txtPrintValue);
txtPrintValue = "";
const counts = {};
for (let i = 0; i < randomValues.length; i++) {
    const num = randomValues[i];
    if (counts[num]) {
        counts[num] = counts[num] + 1;
    } else {
        counts[num] = 1;
    }
}

function countCompare(aValue1, aValue2) {
    return counts[aValue2] - counts[aValue1];
}

const countsKeys = Object.keys(counts);
countsKeys.sort(countCompare);
for (let i = 0; i < countsKeys.length; i++) {
    const key = countsKeys[i];
    txtPrintValue += key.setSize(2, '\u00a0', true) + ": " + counts[key] + " ganger" + NEWLine;
}
printOut(txtPrintValue);

const topCount = {};
let countKey = countsKeys[0];
for (let i = 1; i < countsKeys.length; i++) {
    let count = counts[countKey];
    const key = countsKeys[i];
    if (counts[key] === counts[countKey]) {
        if (topCount[count]) {
            topCount[count].push(parseInt(key));
        } else {
            topCount[count] = [parseInt(countKey), parseInt(key)];
        }
    } else {
        if (i > 1) {
            countKey = key;
            count = counts[countKey];
        }
        if (topCount[count]) {
            topCount[count].push(parseInt(countKey));
        } else {
            topCount[count] = [parseInt(countKey)];
        }
    }
    countKey = key;
}

const topCountKeys = Object.keys(topCount);
for (let i = 0; i < topCountKeys.length; i++) {
    const key = topCountKeys[i];
    const count = topCount[key];
    if (count.length === 1) {
        txtPrintValue = "Tallet ";
    } else {
        txtPrintValue = "Tallene: ";
    }
    txtPrintValue += count.join(", ") + " forekommer " + key + " ganger!";
    printOut(txtPrintValue)
}

txtPrintValue = "";
printOut(txtPrintValue);


txtPrintValue = "------- Oppgave 10 ------------------------------";
printOut(txtPrintValue);
txtPrintValue = "";

const myTable = [];
for (let row = 0; row < 5; row++) {
    const newRow = [];
    for (let col = 0; col < 9; col++) {
        const cell = "[K" + col.toString() + "R" + row.toString() + "]";
        newRow.push(cell);
    }
    myTable.push(newRow);
}

for (let row = 0; row < 5; row++) {
    txtPrintValue = "";
    for (let col = 0; col < 9; col++) {
        txtPrintValue += myTable[row][col];
    }
    printOut(txtPrintValue);
}

printOut("");

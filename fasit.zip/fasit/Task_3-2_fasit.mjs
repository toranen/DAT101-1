"use strict";

import { initPrintOut, printOut, NEWLine } from "../common/script/utils.mjs";
initPrintOut(document.getElementById("txtOut"));

/* Put your code below here!*/
let txtPrintValue;
printOut("----  Task 1 -----");
txtPrintValue = "";
for (let count = 1; count <= 10; count++) {
  txtPrintValue += count.toString();
  if (count < 10) {
    txtPrintValue += ",";
  }
}
txtPrintValue += NEWLine;
for (let count = 10; count >= 1; count--) {
  txtPrintValue += count.toString();
  if (count > 1) {
    txtPrintValue += ",";
  }
}
printOut(txtPrintValue + NEWLine);
printOut("----  Task 2 -----");
const task1Number = 45;
let guess = 0;
do {
  guess = Math.ceil(Math.random() * 60);
} while (guess !== task1Number);
txtPrintValue = "Tallet er " + guess.toString();
printOut(txtPrintValue + NEWLine);

printOut("----  Task 3 -----");
const task3Guess = 456738;
let task3CountGuess = 0;
const task3DateNow = Date.now();
let task3Number;
do {
  task3Number = Math.ceil(Math.random() * 1000000);
  task3CountGuess++;
} while (task3Number !== task3Guess);
txtPrintValue = "Tallet er " + task3Number.toString() + NEWLine;
txtPrintValue += "Datamaskinen brukte " + task3CountGuess.toString() + " runder" + NEWLine;
const deltaTime = Date.now() - task3DateNow;
txtPrintValue += "Og det tok " + deltaTime.toString() + "millisek.";
printOut(txtPrintValue + NEWLine);

printOut("----  Task 4 -----");
txtPrintValue = "";
for (let count = 2; count <= 200; count++) {
  let divide = count - 1;
  let rest = count % divide === 0;
  while (rest === false && divide > 1) {
    rest = count % divide === 0;
    divide--;
  }
  if (rest === false) {
    txtPrintValue += count.toString();
    if (count < 199) {
      txtPrintValue += ",";
    }
  }
}
printOut(txtPrintValue + NEWLine);

printOut("----  Task 5 -----");
txtPrintValue = "";
for (let row = 1; row <= 7; row++) {
  for (let col = 1; col <= 9; col++) {
    txtPrintValue += "K" + col.toString();
    txtPrintValue += "R" + row.toString() + "&nbsp;&nbsp;&nbsp;";
  }
  txtPrintValue += NEWLine;
}
printOut(txtPrintValue + NEWLine);

printOut("----  Task 6 -----");
txtPrintValue = "";
const task6MaxPoints = 236;
let student1 = Math.ceil(Math.random() * task6MaxPoints);
let student2 = Math.ceil(Math.random() * task6MaxPoints);
let student3 = Math.ceil(Math.random() * task6MaxPoints);
let student4 = Math.ceil(Math.random() * task6MaxPoints);
let student5 = Math.ceil(Math.random() * task6MaxPoints);
for (let i = 1; i <= 5; i++) {
  let studentPoints = 0;
  switch (i) {
    case 1:
      studentPoints = student1;
      break;
    case 2:
      studentPoints = student2;
      break;
    case 3:
      studentPoints = student3;
      break;
    case 4:
      studentPoints = student4;
      break;
    case 5:
      studentPoints = student5;
      break;
  }
  let studentPercent = (studentPoints / task6MaxPoints) * 100;
  let studentGrade = "";
  if (studentPercent < 40) {
    studentGrade = "F";
  } else if (studentPercent < 52) {
    studentGrade = "E";
  } else if (studentPercent < 64) {
    studentGrade = "D";
  } else if (studentPercent < 76) {
    studentGrade = "C";
  } else if (studentPercent < 88) {
    studentGrade = "B";
  } else {
    studentGrade = "A";
  }
  txtPrintValue = "Kandidat " + i.toString() + ": ";
  txtPrintValue += "fikk " + studentPoints.toString() + " poeng. ";
  txtPrintValue += "Som er " + studentPercent.toFixed(0) + "%, og gir karakter " + studentGrade;
  printOut(txtPrintValue);
}
printOut("");
printOut("Same resultat bare i sortert rekkefølge");
/*
  Sort the output by points withouth using arrays.
  Using for and do/while loops.
*/
for (let i = 1; i <= 5; i++) {
  debugger;
  let sorted = true;
  do {
    sorted = true;
    switch (i) {
      case 1:
        if (student1 < student2) {
          let temp = student1;
          student1 = student2;
          student2 = temp;
          sorted = false;
        }
        break;
      case 2:
        if (student2 < student3) {
          let temp = student2;
          student2 = student3;
          student3 = temp;
          sorted = false;
        }
        break;
      case 3:
        if (student3 < student4) {
          let temp = student3;
          student3 = student4;
          student4 = temp;
          sorted = false;
        }
        break;
      case 4:
        if (student4 < student5) {
          let temp = student4;
          student4 = student5;
          student5 = temp;
          sorted = false;
        }
        break;
      case 5:
        if (student1 > student2 || student2 > student3 || student3 > student4 || student4 > student3) {
          sorted = true;
        }
        break;
    }
  } while (!sorted);
  printOut("Kandidat " + i.toString() + ": fikk " + student1.toString() + " poeng.");
}

printOut("----  Task 7 -----");
txtPrintValue = "";
let rolls = 0;
let done = false;
let hasYahtzee = false; // True if we have already got Yahtzee
let hasStraight = false; // True if we have already got Straight
let has3Pair = false; // True if we have already got 3 pair
let hasTower = false; // True if we have already got four and two equals
do {
  const d1 = Math.ceil(Math.random() * 6); // Dice one
  const d2 = Math.ceil(Math.random() * 6); // Dice two
  const d3 = Math.ceil(Math.random() * 6); // Dice three
  const d4 = Math.ceil(Math.random() * 6); // Dice four
  const d5 = Math.ceil(Math.random() * 6); // Dice five
  const d6 = Math.ceil(Math.random() * 6); // Dice six
  const txtD = d1 + "," + d2 + "," + d3 + "," + d4 + "," + d5 + "," + d6; // make string of all dice's
  rolls++; // increase rolls with one, computer has rolled all dices.
  // Check to see if all dice are equal (Yahtzee!)
  if (d1 === d2 && d1 === d3 && d1 === d4 && d1 === d5 && d1 === d6) {
    // All dice are equal, check if we already has got Yahtzee
    if (hasYahtzee === false) {
      hasYahtzee = true;
      txtPrintValue += txtD + NEWLine;
      txtPrintValue += "Yatzi!" + NEWLine;
      txtPrintValue += "På " + rolls.toString() + " kast!" + NEWLine + NEWLine;
    }
  } else {
    // All dice are not equal, count each number of occurrence
    // Find match for each 1,2,3,4,5,6, if no match found use a empty string so length will work.
    const cD1 = (txtD.match(/1/g) || "").length;
    const cD2 = (txtD.match(/2/g) || "").length;
    const cD3 = (txtD.match(/3/g) || "").length;
    const cD4 = (txtD.match(/4/g) || "").length;
    const cD5 = (txtD.match(/5/g) || "").length;
    const cD6 = (txtD.match(/6/g) || "").length;
    if (cD1 === 1 && cD2 === 1 && cD3 === 1 && cD4 === 1 && cD5 === 1 && cD6 === 1) {
      // All dice are different, check if we already got Straight
      if (hasStraight === false) {
        hasStraight = true;
        txtPrintValue += txtD + NEWLine;
        txtPrintValue += "Full straight" + NEWLine;
        txtPrintValue += "På " + rolls.toString() + " Kast!" + NEWLine + NEWLine;
      }
    } else {
      // we have neither Yahtzee or Straight
      // Count number of equal occurrence
      const txtCD = cD1 + "," + cD2 + "," + cD3 + "," + cD4 + "," + cD5 + "," + cD6;
      const ccD2 = (txtCD.match(/2/g) || "").length;
      const ccD4 = (txtCD.match(/4/g) || "").length;
      if (ccD2 === 3) {
        // Check if we already got 3 pair
        if (has3Pair === false) {
          has3Pair = true;
          txtPrintValue += txtD + NEWLine;
          txtPrintValue += "3 Par" + NEWLine;
          txtPrintValue += "På " + rolls.toString() + " kast!" + NEWLine + NEWLine;
        }
      } else if (ccD2 === 1 && ccD4 === 1) {
        // Check if we already got tower
        if (hasTower === false) {
          hasTower = true;
          txtPrintValue += txtD + NEWLine;
          txtPrintValue += "Tårn" + NEWLine;
          txtPrintValue += "På " + rolls.toString() + " kast!" + NEWLine + NEWLine;
        }
      }
    }
  }
  done = hasYahtzee && hasStraight;
} while (done === false);
printOut(txtPrintValue + NEWLine);

"use strict";

import { initPrintOut, printOut, NEWLine } from "../common/script/utils.mjs";
initPrintOut(document.getElementById("txtOut"));

  // -------------------------------------------------------------------------------------------------------------------
  // -----    Object and Classes   -------------------------------------------------------------------------------------
  // -------------------------------------------------------------------------------------------------------------------

  const AccountType = {
    Normal: "Brukskonto", Saving: "Sparekonto", Credit: "Kreditkonto", Pension: "Pensionskonto"
  };

  const CurrencyTypes = {
    NOK: {value: 1.0000, name: "Norske kroner"         , denomination: "kr"},
    EUR: {value: 0.0985, name: "Europeiske euro"        , denomination: "€"},
    USD: {value: 0.1091, name: "United States dollar"   , denomination: "$"},
    GBP: {value: 0.0847, name: "Pound sterling"         , denomination: "£"},
    INR: {value: 7.8309, name: "Indiske rupee"          , denomination: "र"},
    AUD: {value: 0.1581, name: "Australienske dollar"   , denomination: "A$"},
    PHP: {value: 6.5189, name: "Filippinske peso"       , denomination: "₱"},
    SEK: {value: 1.0580, name: "Svenske kroner"         , denomination: "kr"},
    CAD: {value: 0.1435, name: "Canadiske dollar"       , denomination: "C$"},
    THB: {value: 3.3289, name: "Thai baht"              , denomination: "฿"}
  };

  function TAccount(aAccountType) {
    let type = aAccountType; // This holds the account type, a private member!
    let balance = 0; // This holds the balance, a private member!
    let withdrawCount = 0; // a counter to check withdraws, a private member!
    let currencyType = CurrencyTypes.NOK; // This holds the account currency, a private member!

    // A method to get access to account type, public member!
    this.toString = function () {
      return type;
    };

    // A method to set the account type, public member!
    this.setType = function (aType) {
      if (aType === type) {
        return; // If type is unchanged, just return to the caller!
      }
      printOut("Account is changed from " + type + " to " + aType); // Print out information to user!
      type = aType;  // Set the new account type.
      withdrawCount = 0; // Remember to reset the counter
    };

    // A method to get access to account balance, public member!
    this.getBalance = function () {
      return balance;
    };

    // A method to increase balance, public member!
    this.deposit = function (aAmount, aType = CurrencyTypes.NOK) {
      withdrawCount = 0; // Remember to reset the counter
      balance += aAmount / currencyConvert(aType); // Increase the balance
      //balance = parseFloat(balance.toFixed(2)); // Remove all decimal 0.00xxxxxx
      printOut("Deposit of " + aAmount.toFixed(2) + " " + aType.name + ", new balance is " + balance.toFixed(2) + currencyType.denomination);
    };

    // A method to decrease balance, public member!
    this.withdraw = function (aAmount, aType = CurrencyTypes.NOK) {
      let canWithdraw = true; // Assume that withdraw is allowed!
      switch (type) {
        case AccountType.Pension:
          canWithdraw = false; // It's not allowed to withdraw from pension account
          printOut("You can't withdraw from a " + type + "!");
          break;
        case AccountType.Saving:
          if (withdrawCount >= 3) {
            canWithdraw = false; // It's not allowed to withdraw from saving more than three times
            printOut("You can't Withdraw from a " + type + " more than three times!");
          }
          break;
      }
      if (canWithdraw) {
        balance -= aAmount / currencyConvert(aType); // Decrease the balance
        balance = parseFloat(balance.toFixed(2));
        printOut("Withdrawal of " + aAmount.toFixed(2) + " " + aType.name + ", new balance is " + balance.toFixed(2) + currencyType.denomination);
        withdrawCount++; // Remember to increase the counter
      }
    };

    // A method to to change the account currency, public member!
    this.setCurrencyType = function (aType) {
      if (currencyType === aType) {
        return; // If type is unchanged, just return to the caller!
      }
      printOut("The account currency has change from " + currencyType.name + " to " + aType.name);
      const convertValue = currencyConvert(aType); // convert old currency to the new
      const newBalance = balance * convertValue; // change the balance to new currency.
      const txtBalance = newBalance.toFixed(2); // Remove decimals 0.00xxxxxxx
      balance = parseFloat(txtBalance); // Convert the text-based balance bak to number-based
      currencyType = aType; // Change the currency type
      printOut("New balance is " + balance.toFixed(2) + currencyType.denomination);
    };

    // A method to to convert between currencies, private member!
    function currencyConvert(aType){
      return  CurrencyTypes.NOK.value / currencyType.value * aType.value;
    }
  }

  /* Put your code below here!*/
  let txtPrintValue;
  printOut("----------- Task 1 --------------------");

  txtPrintValue = AccountType.Normal + ", " + AccountType.Saving + ", " + AccountType.Credit + ", " + AccountType.Pension;
  printOut(txtPrintValue + NEWLine);

  printOut("----------- Task 2 --------------------");

  // Create one account
  const myAccount = new TAccount(AccountType.Normal);
  // Print out the account information
  printOut("myAccount = " + myAccount.toString());
  // Change the account type
  myAccount.setType(AccountType.Saving);
  // Print out the account information again
  printOut("myAccount = " + myAccount.toString() + NEWLine);

  printOut("----------- Task 3 --------------------");
  myAccount.deposit(100);
  myAccount.withdraw(25);
  txtPrintValue = "My account balance is " + myAccount.getBalance();
  printOut(txtPrintValue + NEWLine);

  printOut("----------- Task 4 --------------------");
  myAccount.deposit(25);
  myAccount.withdraw(30);
  myAccount.withdraw(30);
  myAccount.withdraw(30);
  myAccount.withdraw(30);
  txtPrintValue = "My account balance is " + myAccount.getBalance();
  myAccount.setType(AccountType.Pension);
  myAccount.withdraw(50);
  myAccount.setType(AccountType.Saving);
  myAccount.withdraw(10);

  printOut(NEWLine + "----------- Task 5 --------------------");
  myAccount.deposit(150);

  printOut(NEWLine + "----------- Task 6 --------------------");
  myAccount.setCurrencyType(CurrencyTypes.SEK);
  myAccount.setCurrencyType(CurrencyTypes.USD);
  myAccount.setCurrencyType(CurrencyTypes.NOK);

  printOut(NEWLine + "----------- Task 7 --------------------");
  myAccount.deposit(12, CurrencyTypes.USD);
  myAccount.withdraw(10, CurrencyTypes.GBP);
  myAccount.setCurrencyType(CurrencyTypes.CAD);
  myAccount.setCurrencyType(CurrencyTypes.SEK);
  myAccount.setCurrencyType(CurrencyTypes.INR);
  myAccount.withdraw(150.11,CurrencyTypes.SEK);

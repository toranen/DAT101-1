"use strict";

import { initPrintOut, printOut } from "../common/script/utils.mjs";
initPrintOut(document.getElementById("txtOut"));

"use strict";
const EnterKey = 13;
const NEWLine = "\r\n";
const txtRectWidth = document.getElementById("txtRectWidth");
const txtRectHeight = document.getElementById("txtRectHeight");
const txtTask1Output = document.getElementById("txtTask1Output");
const cmbTask1Calculate = document.getElementById("cmbTask1Calculate");
cmbTask1Calculate.addEventListener("click", cmbTask1CalculateClick);

const txtTask2Word = document.getElementById("txtTask2Word");
txtTask2Word.addEventListener("keypress", txtTask2WordKeyPress);
const txtTask2Output = document.getElementById("txtTask2Output");

const chkTask3 = document.getElementsByName("chkTask3");
const cmbTask3CheckAnswer = document.getElementById("cmbTask3CheckAnswer");
cmbTask3CheckAnswer.addEventListener("click", cmbTask3CheckAnswerClick);
const txtTask3Output = document.getElementById("txtTask3Output");

const txtTask4Output = document.getElementById("txtTask4Output");

const selectTask4Animals = document.getElementById("selectTask4Animals");
selectTask4Animals.addEventListener("change", selectTask5AnimalsChange);
const txtTask5Output = document.getElementById("txtTask5Output");

const selectTask6Girls = document.getElementById("selectTask6Girls");
selectTask6Girls.addEventListener("change", selectTask6GirlsChange);
const txtTask6Output = document.getElementById("txtTask6Output");

const txtMovieTitle = document.getElementById("txtMovieTitle");
const selectMovieGenre = document.getElementById("selectMovieGenre");
const txtMovieDirector = document.getElementById("txtMovieDirector");
const txtMovieRate = document.getElementById("txtMovieRate");
const tblMovies = document.getElementById("tblMovies");
const cmbAddMovie = document.getElementById("cmbAddMovie");
cmbAddMovie.addEventListener("click", cmbAddMovieClick);


const Task2Words = [];

const CarTypes = [
  {value: 1, caption: "Aston Martin"},
  {value: 2, caption: "Bentley"},
  {value: 3, caption: "Alfa Romeo"},
  {value: 4, caption: "Ferrari"},
  {value: 5, caption: "Subaru"},
  {value: 6, caption: "Porsche"},
  {value: 7, caption: "Tesla"},
  {value: 8, caption: "Toyota"},
  {value: 9, caption: "Renault"},
  {value: 10, caption: "Peugeot"},
  {value: 11, caption: "Suzuki"},
  {value: 12, caption: "Mitsubishi"},
  {value: 13, caption: "Nissan"},
];

const GirlsNames = ["Anne", "Inger", "Kari", "Marit", "Ingrid", "Liv", "Eva", "Berit", "Astrid", "Bjørg", "Hilde",
  "Anna", "Solveig", "Marianne", "Randi", "Ida", "Nina", "Maria", "Elisabeth", "Kristin"];

const divTask4Cars = document.getElementById("divTask4Cars");

const MovieGenre = ["Action", "Adventure", "Animation", "Biography", "Comedy", "Crime", "Documentary",
  "Drama", "Family", "Fantasy", "Film Noir", "History", "Horror", "Music", "Musical", "Mystery", "Romance",
  "Sci-Fi", "Short", "Sport", "Superhero", "Thriller", "War", "Western"];

for (let i = 0; i < CarTypes.length; i++) {
  const newLabel = document.createElement("label");
  const newCheckBox = document.createElement("input");
  newCheckBox.type = "radio";
  newCheckBox.name = "radioGroup1";
  newCheckBox.name = "Task3Cars";
  newCheckBox.checked = false;
  newCheckBox.value = CarTypes[i].value;
  newCheckBox.addEventListener("change", chkTask4CarChange);
  newLabel.appendChild(newCheckBox);
  newLabel.appendChild(document.createTextNode(CarTypes[i].caption));
  divTask4Cars.appendChild(newLabel);
  divTask4Cars.appendChild(document.createElement("br"));
}

for (let i = 0; i < GirlsNames.length; i++) {
  const newOption = document.createElement("option");
  newOption.value = i;
  newOption.innerText = GirlsNames[i];
  selectTask6Girls.appendChild(newOption);
}
txtTask6Output.innerText = "You selected: " + GirlsNames[0];

for(let i = 0; i < MovieGenre.length; i++){
  const newOption = document.createElement("option");
  newOption.value = i.toString();
  newOption.innerText = MovieGenre[i];
  selectMovieGenre.appendChild(newOption);
}

const myMovies = [
  ["Star Wars: Episode IX - The Rise of Skywalker", 9, "J.J. Abrams", 7 ],
  ["6 Underground",0, "Michael Bay", 6 ],
  ["Jumanji: The Next Level",1, "Jake Kasdan", 7],
  ["Star Wars: Episode VIII - The Last Jedi",9, "Rian Johnson", 7],
];
for(let i = 0; i < myMovies.length; i++){
  const newRow = tblMovies.insertRow();
  let cell = newRow.insertCell();
  cell.innerText = (tblMovies.rows.length - 1).toString();
  cell = newRow.insertCell();
  cell.innerText = myMovies[i][0];
  cell = newRow.insertCell();
  cell.innerText = MovieGenre[myMovies[i][1]];
  cell = newRow.insertCell();
  cell.innerText = myMovies[i][2];
  cell = newRow.insertCell();
  cell.innerText = myMovies[i][3].toString();

}

// ---------------- Events -------------------------------------------------------------------------------------------
function cmbTask1CalculateClick() {
  const height = parseInt(txtRectHeight.value);
  const width = parseInt(txtRectWidth.value);
  txtTask1Output.innerText = "Circumference = " + ((2 * height) + (2 * width)).toString();
  txtTask1Output.innerText += " , Area = " + (height * width).toString();
}

function txtTask2WordKeyPress(aEvent) {
  if (aEvent.which === EnterKey) {
    Task2Words.push(txtTask2Word.value);
    txtTask2Output.innerText = "Number of words = " + Task2Words.length.toString() + NEWLine;
    txtTask2Output.innerText += Task2Words.join(" ");
    txtTask2Word.value = "";
  }
}

function cmbTask3CheckAnswerClick() {
  txtTask3Output.innerText = "";
  for (let i = 0; i < chkTask3.length; i++) {
    if (chkTask3[i].checked) {
      txtTask3Output.innerText += "You answer number " + chkTask3[i].value + NEWLine;
    }
  }
}

function chkTask4CarChange(aEvent) {
  txtTask4Output.innerText = "";
  if (aEvent.target.checked) {
    txtTask4Output.innerText = "You checked nr: " + aEvent.target.value;
  }
}

function selectTask5AnimalsChange() {
  txtTask5Output.innerText = "You selected nr: " + selectTask4Animals.value;
}

function selectTask6GirlsChange() {
  const index = parseInt(selectTask6Girls.value);
  txtTask6Output.innerText = "You selected: " + GirlsNames[index];
}

function cmbAddMovieClick(){
  const newRow = tblMovies.insertRow();
  let cell = newRow.insertCell();
  cell.innerText = (tblMovies.rows.length - 1).toString();
  cell = newRow.insertCell();
  cell.innerText = txtMovieTitle.value;
  cell = newRow.insertCell();
  cell.innerText = MovieGenre[selectMovieGenre.value];
  cell = newRow.insertCell();
  cell.innerText = txtMovieDirector.value;
  cell = newRow.insertCell();
  cell.innerText = txtMovieRate.value;
}

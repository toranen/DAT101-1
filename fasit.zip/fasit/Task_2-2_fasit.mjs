"use strict";

import { initPrintOut, printOut } from "../common/script/utils.mjs";
initPrintOut(document.getElementById("txtOut"));

/* Constants and variables*/
let txtPrintValue;

/* Oppgave 1*/
printOut("--- Oppgave 1 ----------------------------------------------------------------------------------------------");
let a = 2 + (3 * (2 - 4)) * 6;
txtPrintValue = " 2 + (3 * (2 - 4)) * 6 = " + a.toString();
printOut(txtPrintValue);
printOut("----------------------------------------------------------------------------------------------------------");
printOut(" ");


/* Oppgave 2*/
printOut("--- Oppgave 2 ----------------------------------------------------------------------------------------------");
let convertFrom = (25 * 1000) + (34 * 10);
let convertTo = convertFrom / 25.4;
txtPrintValue = "25 meters and 34 centimeters = " + convertTo.toFixed(2);
printOut(txtPrintValue);
printOut("----------------------------------------------------------------------------------------------------------");
printOut(" ");

/* Oppgave 3*/
printOut("--- Oppgave 3 ----------------------------------------------------------------------------------------------");
let task3Minutes = (3 * 24 * 60) + (12 * 60) + 14 + (45 / 60);
txtPrintValue = "3 days, 12 hours, 14 minutes and 45 seconds = " + task3Minutes.toString();
printOut(txtPrintValue);
printOut("----------------------------------------------------------------------------------------------------------");
printOut(" ");

/* Oppgave 4*/
printOut("--- Oppgave 4 ----------------------------------------------------------------------------------------------");
txtPrintValue = "6322.52 minutes is: "; // Prepare text for print out
const task4Minutes = 6322.52; //Assign minutes given in Oppgave description
let task4Temp = task4Minutes / (24 * 60); //Calculate days.
let task4Rest = Math.floor(task4Temp); //Remove fraction of days.
txtPrintValue += task4Rest.toString() + " Days, "; //Add days to print out
task4Temp = (task4Temp - task4Rest) * 24; //Calculate hour of days fraction
task4Rest = Math.floor(task4Temp);
txtPrintValue += task4Rest.toString() + " Hours, "; //Add days to print out
task4Temp = (task4Temp - task4Rest) * 60; //Calculate hour of days fraction
task4Rest = Math.floor(task4Temp);
txtPrintValue += task4Rest.toString() + " Minutes, "; //Add days to print out
task4Temp = (task4Temp - task4Rest) * 60; //Calculate hour of days fraction
task4Rest = Math.round(task4Temp);
txtPrintValue += task4Rest.toString() + " Seconds, "; //Add days to print out
printOut(txtPrintValue);
printOut("----------------------------------------------------------------------------------------------------------");
printOut(" ");

/* Oppgave 5*/
printOut("--- Oppgave 5 ----------------------------------------------------------------------------------------------");
let task5Rate = 76 / 8.6;
let task5NOK = Math.round(54 * task5Rate);
txtPrintValue = "54 USD = " + task5NOK.toString() + " NOK";
printOut(txtPrintValue);
let Oppgave5USD = Math.round(task5NOK / task5Rate);
txtPrintValue = task5NOK.toString() + " NOK = " + Oppgave5USD.toString() + " USD";
printOut(txtPrintValue);
printOut("----------------------------------------------------------------------------------------------------------");
printOut(" ");


/* Oppgave 6*/
printOut("--- Oppgave 6 ----------------------------------------------------------------------------------------------");
let task6Text = "Det er mye mellom himmel og jord som vi ikke forstår.";
printOut(task6Text);
txtPrintValue = "The text has " + task6Text.length.toString() + " characters";
printOut(txtPrintValue);
txtPrintValue = "The character at position 19 is:  " + task6Text.charAt(19);
printOut(txtPrintValue);
txtPrintValue = "The substring from 35 and 8 places is: " + task6Text.substr(35, 8);
printOut(txtPrintValue);
txtPrintValue = "The word \"jord\" starts at pos " + task6Text.indexOf("jord");
printOut(txtPrintValue);
printOut("----------------------------------------------------------------------------------------------------------");
printOut(" ");

/* Oppgave 7*/
printOut("--- Oppgave 7 ----------------------------------------------------------------------------------------------");
txtPrintValue = " 5 > 3 is " + (5 > 3).toString();
printOut(txtPrintValue);
txtPrintValue = " 7 >= 7 is " + (7 >= 7).toString();
printOut(txtPrintValue);
txtPrintValue = "\"a\" > \"b\" is " + ("a" > "b").toString();
printOut(txtPrintValue);
txtPrintValue = "\"1\" < \"a\" is " + ("1" > "a").toString();
printOut(txtPrintValue);
txtPrintValue = "\"2500\" < \"abcd\" is " + ("2500" < "abcd").toString();
printOut(txtPrintValue);
txtPrintValue = "\"arne\" !== \"thomas\" is " + ("arne" !== "thomas").toString();
printOut(txtPrintValue);
txtPrintValue = "(2 === 5) === true is " + ((2 === 5) === true).toString();
printOut(txtPrintValue);
txtPrintValue = "(\"abcd\" > \"bcd\") === false is " + (("abcd" > "bcd") === false).toString();
printOut(txtPrintValue);
printOut("----------------------------------------------------------------------------------------------------------");
printOut(" ");

/* Oppgave 8*/
printOut("--- Oppgave 8 ----------------------------------------------------------------------------------------------");
txtPrintValue = "\"254\" = " + parseInt("254").toString();
printOut(txtPrintValue);
txtPrintValue = "\"57.23\" = " + parseFloat("57.23").toString();
printOut(txtPrintValue);
txtPrintValue = "\"25 kroner\" = " + parseInt("25 kroner").toString();
printOut(txtPrintValue);
printOut("----------------------------------------------------------------------------------------------------------");
printOut(" ");

/* Oppgave 9*/
printOut("--- Oppgave 9 ----------------------------------------------------------------------------------------------");
let task9Rand = Math.ceil(Math.random() * 360);
txtPrintValue = "Math.ceil(Math.random() * 360) = " + task9Rand;
printOut(txtPrintValue);
printOut("----------------------------------------------------------------------------------------------------------");
printOut(" ");

/* Oppgave 10*/
printOut("--- Oppgave 10 ----------------------------------------------------------------------------------------------");
let task10Weeks = Math.floor(131 / 7);
let task10Days = 131 % 7;
txtPrintValue = "131 days is " + task10Weeks.toString() + " weeks and " + task10Days.toString() + " days.";
printOut(txtPrintValue);
printOut("----------------------------------------------------------------------------------------------------------");

"use strict";

import { initPrintOut, printOut, NEWLine } from "../common/script/utils.mjs";
initPrintOut(document.getElementById("txtOut"));
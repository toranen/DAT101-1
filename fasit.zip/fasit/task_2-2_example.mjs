"use strict";
import { initPrintOut, printOut, newLine } from "../../common/script/utils.mjs";
initPrintOut(document.getElementById("txtOut"));

printOut("--- Part 1 ----------------------------------------------------------------------------------------------");
/*Calculate '2 + 3 * 2 - 4 * 6', ensuring the result is -34.*/
const result = 2 + 3 * (2 - 4) * 6;

printOut("2 + (3 * (2 - 4)) * 6 = " + result.toString());
printOut(newLine);

printOut("--- Part 2 ----------------------------------------------------------------------------------------------");
/* 
  - Convert 25 metres and 34 centimeters to inches.
  - An inch is 25.4 millimeters (maximum 2 decimal places in the answer).
*/
const part2_Metres = 25.34;
const part2_Inches = 1000 / 25.4;
const part2_Answer = (part2_Metres * part2_Inches).toFixed(2);
printOut(part2_Metres + " meters is equal to " + part2_Answer + " inches.");
printOut(newLine);

printOut("--- Part 3 ----------------------------------------------------------------------------------------------");
/*
 - Convert 3 days, 12 hours, 14 minutes, and 45 seconds to minutes. (Not allowed to use date objects).
 - The task must be solved with primitives*/

const HoursInDay = 24;
const MinutesPerHour = 60;
const MinutesPerDay = MinutesPerHour * HoursInDay;

const part3_Days = 3;
const part3_Hours = 12;
const part3_Minutes = 14;
const part3_Seconds = 45;
const part3_TotalMinutes = part3_Days * MinutesPerDay + part3_Hours * MinutesPerHour + part3_Minutes + part3_Seconds / MinutesPerHour;
printOut(part3_Days + " days, " + part3_Hours + " hours, " + part3_Minutes + " minutes, and " + part3_Seconds + " seconds is equal to " + part3_TotalMinutes + " minutes.");
printOut(newLine);

printOut("--- Part 4 ----------------------------------------------------------------------------------------------");
/*
 - Convert 6,322.52 minutes to days, hours, minutes, and seconds. (Not allowed to use date objects).
  - The task must be solved with primitives.
*/
const part4_TotalMinutes = 6322.52;
const SecondsInMinute = 60;

let part4_Calc = part4_TotalMinutes / MinutesPerDay;
const part4_Days = Math.floor(part4_Calc);
part4_Calc = (part4_Calc - part4_Days) * HoursInDay;
const part4_Hours = Math.floor(part4_Calc);
part4_Calc = (part4_Calc - part4_Hours) * MinutesPerHour;
const part4_Minutes = Math.floor(part4_Calc);
part4_Calc = (part4_Calc - part4_Minutes) * SecondsInMinute;
const part4_Seconds = Math.floor(part4_Calc);
printOut(part4_TotalMinutes + " minutes is equal to " + part4_Days + " days, " + part4_Hours + " hours, " + part4_Minutes + " minutes " + part4_Seconds + " seconds");
printOut(newLine);

printOut("--- Part 5 ----------------------------------------------------------------------------------------------");
/*
 - Convert 54 dollars to Norwegian kroner, and print the price for both:
 - NOK → USD and USD → NOK.
 - Use 76 NOK = 8.6 USD as the exchange rate.
*/

const NOK = 76 / 8.6;
const USD = 8.6 / 76;
printOut("NOK + " + NOK + ", USD = " + USD);

let part5_AmountUSD = 54;
const part5_AmountNOK =  Math.round(part5_AmountUSD * NOK);
printOut(part5_AmountUSD + " dollars is " + part5_AmountNOK + " kroner");

part5_AmountUSD =  Math.round(part5_AmountNOK * USD);
printOut(part5_AmountNOK + " kroner is " + part5_AmountUSD + " US dollars");
printOut(newLine);

printOut("--- Part 6 ----------------------------------------------------------------------------------------------");
/* Put your code below here!*/
printOut("Replace this with you answer!");
printOut(newLine);

printOut("--- Part 7 ----------------------------------------------------------------------------------------------");
/* Put your code below here!*/
printOut("Replace this with you answer!");
printOut(newLine);

printOut("--- Part 8 ----------------------------------------------------------------------------------------------");
/* Put your code below here!*/
printOut("Replace this with you answer!");
printOut(newLine);

printOut("--- Part 9 ----------------------------------------------------------------------------------------------");
/* Put your code below here!*/
printOut("Replace this with you answer!");
printOut(newLine);

/* Task 10*/
printOut("--- Part 10 ---------------------------------------------------------------------------------------------");
/* Put your code below here!*/
printOut("Replace this with you answer!");
printOut(newLine);

"use strict";

import { initPrintOut, printOut, NEWLine } from "../common/script/utils.mjs";
initPrintOut(document.getElementById("txtOut"));

	/* Put your code below here!*/
	let txtPrintValue;

  /* Oppgave 1, 2 and 3*/
  printOut("Oppgave 1, 2 and 3");
  let wakeUpTime = 8;
  const Oppgave1TakeBuss = 7;
  const Oppgave3TakeTrain = 8;
  txtPrintValue = "Wake up time = " + wakeUpTime.toString();
  printOut(txtPrintValue);
  if (wakeUpTime === Oppgave1TakeBuss) {
    txtPrintValue = "I can take the bus to school.";
  } else if (wakeUpTime === Oppgave3TakeTrain) {
    txtPrintValue = "I can take the train to school";
  } else {
    txtPrintValue = "I need to take the car to school";
  }
  printOut(txtPrintValue + NEWLine);

  /* Oppgave 4 and 5*/
  printOut("Oppgave 4 and 5");
  const Oppgave4Value = -1;
  txtPrintValue = "Oppgave 4 value = " + Oppgave4Value.toString();
  printOut(txtPrintValue);
  if (Oppgave4Value > 0) {
    txtPrintValue = "Value is positive";
  } else if (Oppgave4Value < 0) {
    txtPrintValue = "Value is negative";
  } else {
    txtPrintValue = "Value is zero";
  }
  printOut(txtPrintValue + NEWLine);


  /* Oppgave 6 and 7*/
  printOut("Oppgave 6 and 7");
  const Oppgave6PhotoSize = Math.floor(Math.random() * 7) + 1;
  const Oppgave6LowerLimit = 4;
  const Oppgave7UpperLimit = 6;
  txtPrintValue = "Oppgave 6 photo size = " + Oppgave6PhotoSize.toString();
  printOut(txtPrintValue);
  if (Oppgave6PhotoSize > Oppgave7UpperLimit) {
    txtPrintValue = "Image is too large";
  } else if (Oppgave6PhotoSize >= Oppgave6LowerLimit) {
    txtPrintValue = "Thank you";
  } else {
    txtPrintValue = "Image is too small";
  }
  printOut(txtPrintValue + NEWLine);

  /* Oppgave 8*/
  printOut("Oppgave 8");

  const monthList = ["January", "February", "Mars", "April", "Mai", "Jun", "Juli", "August", "September", "October", "November", "December"];
  const noOfMonth = monthList.length;
  const monthName = monthList[Math.floor(Math.random() * noOfMonth)];

  printOut("Month is = " + monthName);
  if ((monthName === "Mai") || (monthName === "Jun") || (monthName === "Juli") || (monthName === "August")) {
    txtPrintValue = "You don't need to take vitamin D";
  } else {
    txtPrintValue = "You need to take vitamin D";
  }
  printOut(txtPrintValue + NEWLine);

  /* Oppgave 9*/
  printOut("Oppgave 9");

  let Oppgave9Days = 0;
  switch (monthName) {
    case "January":
      Oppgave9Days = 31;
      break;
    case "February":
      Oppgave9Days = 28;
      break;
    case "Mars":
      Oppgave9Days = 31;
      break;
    case "April":
      Oppgave9Days = 30;
      break;
    case "Mai":
      Oppgave9Days = 31;
      break;
    case "Jun":
      Oppgave9Days = 30;
      break;
    case "Juli":
      Oppgave9Days = 31;
      break;
    case "August":
      Oppgave9Days = 31;
      break;
    case "September":
      Oppgave9Days = 30;
      break;
    case "October":
      Oppgave9Days = 31;
      break;
    case "November":
      Oppgave9Days = 30;
      break;
    case "December":
      Oppgave9Days = 31;
      break;
  }
  txtPrintValue = "It is " + Oppgave9Days.toString() + " days in " + monthName;
  printOut(txtPrintValue + NEWLine);

  /* Oppgave 10*/
  printOut("Oppgave 10");

  switch(monthName){
    case "Mars":
    case "Mai":
      txtPrintValue = "I'm sorry, the art gallery is closed in " + monthName;
      break;
    case "April":
      txtPrintValue = "I'm sorry, the main art gallery is closed in " + monthName + "." + NEWLine +
        "However, I have some temporary premises next door you can visit.";
      break;
    default:
      txtPrintValue = "The Art gallery is open in " + monthName + ", Welcome!";
  }
  printOut(txtPrintValue + NEWLine);
